import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get recent messages
  app.get("/api/messages", async (req, res) => {
    try {
      const messages = await storage.getRecentMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Send a message and get AI response
  app.post("/api/messages", async (req, res) => {
    try {
      const { content } = insertMessageSchema.parse(req.body);
      
      // Save user message
      const userMessage = await storage.createMessage({
        content,
        sender: "user",
      });

      // Generate AI response
      const aiResponse = await generateAIResponse(content, req.query.category as string);
      
      // Save AI message
      const botMessage = await storage.createMessage({
        content: aiResponse,
        sender: "bot",
      });

      res.json({ userMessage, botMessage });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid message format" });
      } else {
        res.status(500).json({ error: "Failed to send message" });
      }
    }
  });

  // Get knowledge base
  app.get("/api/knowledge", async (req, res) => {
    try {
      const category = req.query.category as string;
      const knowledge = category && category !== 'all' 
        ? await storage.getKnowledgeByCategory(category)
        : await storage.getAllKnowledge();
      
      res.json(knowledge);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch knowledge base" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

async function generateAIResponse(question: string, category?: string): Promise<string> {
  const lowerQuestion = question.toLowerCase();
  
  // Get knowledge base filtered by category
  const knowledge = category && category !== 'all'
    ? await storage.getKnowledgeByCategory(category)
    : await storage.getAllKnowledge();

  // Find exact matches first
  for (const item of knowledge) {
    for (const q of item.questions) {
      if (lowerQuestion.includes(q.toLowerCase()) || q.toLowerCase().includes(lowerQuestion)) {
        return item.response;
      }
    }
  }

  // Fuzzy matching for partial matches
  for (const item of knowledge) {
    for (const q of item.questions) {
      const questionWords = q.toLowerCase().split(' ');
      const inputWords = lowerQuestion.split(' ');
      
      const matchCount = questionWords.filter(word => 
        inputWords.some(inputWord => inputWord.includes(word) || word.includes(inputWord))
      ).length;
      
      if (matchCount >= Math.ceil(questionWords.length * 0.6)) {
        return item.response;
      }
    }
  }

  // Fallback responses
  const fallbacks = [
    "Je comprends ta question, mais je n'ai pas encore d'information spécifique là-dessus. Peux-tu la reformuler différemment? 🤔",
    "C'est une question intéressante! Pour l'instant, je me concentre sur l'éducation, le business et les conseils pratiques. Essaie une question dans ces domaines! 💡",
    "Je n'ai pas encore appris cette information, mais je grandis chaque jour! En attendant, demande-moi quelque chose sur l'éducation, les affaires ou la vie pratique en Afrique! 🌍",
  ];

  return fallbacks[Math.floor(Math.random() * fallbacks.length)];
}
