import { messages, knowledgeBase, type Message, type InsertMessage, type Knowledge, type InsertKnowledge } from "@shared/schema";

export interface IStorage {
  // Messages
  createMessage(message: InsertMessage): Promise<Message>;
  getRecentMessages(limit?: number): Promise<Message[]>;
  
  // Knowledge Base
  createKnowledge(knowledge: InsertKnowledge): Promise<Knowledge>;
  getAllKnowledge(): Promise<Knowledge[]>;
  getKnowledgeByCategory(category: string): Promise<Knowledge[]>;
}

export class MemStorage implements IStorage {
  private messages: Map<number, Message>;
  private knowledge: Map<number, Knowledge>;
  private currentMessageId: number;
  private currentKnowledgeId: number;

  constructor() {
    this.messages = new Map();
    this.knowledge = new Map();
    this.currentMessageId = 1;
    this.currentKnowledgeId = 1;
    
    // Initialize with African-focused knowledge base
    this.initializeKnowledgeBase();
  }

  private async initializeKnowledgeBase() {
    const initialKnowledge: InsertKnowledge[] = [
      // Education
      {
        category: 'education',
        questions: ["qu'est-ce qu'une cellule", "définition cellule", "cellule biologie"],
        response: "Une cellule est l'unité de base de tout être vivant. Elle contient l'ADN et assure les fonctions vitales comme la respiration, la nutrition et la reproduction. C'est comme une petite usine qui fait fonctionner la vie! 🔬"
      },
      {
        category: 'education',
        questions: ["photosynthèse", "définition photosynthèse", "plantes lumière"],
        response: "La photosynthèse permet aux plantes de produire de l'énergie à partir de la lumière du soleil. Elles transforment le CO2 et l'eau en glucose et oxygène. C'est grâce à ce processus que nous pouvons respirer! 🌱☀️"
      },
      {
        category: 'education',
        questions: ["démocratie", "définition démocratie", "système politique"],
        response: "La démocratie est un système où le peuple élit ses représentants librement. En Afrique, nous avons de nombreux exemples de démocraties qui se développent. Chaque vote compte pour construire l'avenir! 🗳️"
      },
      
      // Business
      {
        category: 'business',
        questions: ["gagner argent en ligne", "idées internet", "business digital"],
        response: "Pour gagner de l'argent en ligne en Afrique : créer du contenu YouTube, vendre des produits locaux sur les réseaux sociaux, offrir des services de traduction, créer des formations en ligne, faire de l'affiliation avec des marques africaines. Commence avec ce que tu connais déjà! 💻💰"
      },
      {
        category: 'business',
        questions: ["business sans capital", "entreprise sans argent", "commerce petit budget"],
        response: "Idées de business sans capital en Afrique :\n• Vente d'eau fraîche en sachets\n• Préparation de beignets/mandazi\n• Lavage de motos/vélos\n• Revente de crédit téléphonique\n• Vente de fruits de saison\n• Services de livraison à vélo\n• Tressage/coiffure à domicile\nCommence petit et réinvestis! 🚀"
      },
      {
        category: 'business',
        questions: ["agriculture rentable", "cultiver pour vendre", "farming business"],
        response: "Agriculture rentable en Afrique :\n• Maraîchage (tomates, oignons, légumes verts)\n• Élevage de poules pondeuses\n• Culture de champignons\n• Apiculture pour le miel\n• Culture d'herbes aromatiques\nChoisis selon ton climat et ton marché local! 🌾"
      },
      
      // Practical
      {
        category: 'practical',
        questions: ["économiser argent", "épargner", "gérer budget"],
        response: "Conseils pour économiser en Afrique :\n• Utilise la méthode des 'tontines' avec des amis\n• Évite les achats impulsifs au marché\n• Cuisine à la maison plutôt qu'acheter tout fait\n• Répare au lieu de racheter\n• Groupe tes achats pour négocier les prix\n• Économise même 100 francs par jour! 💰"
      },
      {
        category: 'practical',
        questions: ["trouver emploi", "chercher travail", "job hunting"],
        response: "Pour trouver un emploi en Afrique :\n• Utilise ton réseau (famille, amis, voisins)\n• Visite directement les entreprises\n• Utilise les plateformes locales en ligne\n• Participe aux événements de networking\n• Crée un CV adapté au marché local\n• Montre ta motivation et ta fiabilité! 💼"
      },
      {
        category: 'practical',
        questions: ["apprendre compétence", "se former", "skills development"],
        response: "Développer tes compétences en Afrique :\n• Utilise les formations gratuites en ligne\n• Rejoins des coopératives de métiers\n• Apprends d'un mentor dans ton domaine\n• Pratique avec des projets personnels\n• Participe aux ateliers communautaires\nL'apprentissage continu est la clé du succès! 📚"
      }
    ];

    for (const knowledge of initialKnowledge) {
      await this.createKnowledge(knowledge);
    }
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getRecentMessages(limit = 50): Promise<Message[]> {
    const allMessages = Array.from(this.messages.values());
    return allMessages
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
      .slice(-limit);
  }

  async createKnowledge(insertKnowledge: InsertKnowledge): Promise<Knowledge> {
    const id = this.currentKnowledgeId++;
    const knowledge: Knowledge = {
      ...insertKnowledge,
      id,
    };
    this.knowledge.set(id, knowledge);
    return knowledge;
  }

  async getAllKnowledge(): Promise<Knowledge[]> {
    return Array.from(this.knowledge.values());
  }

  async getKnowledgeByCategory(category: string): Promise<Knowledge[]> {
    return Array.from(this.knowledge.values()).filter(k => k.category === category);
  }
}

export const storage = new MemStorage();
