# MDG Helper - AI Assistant for Africa

## Overview

MDG Helper is a full-stack React application that provides an AI-powered chat assistant specifically designed for African users. The application features a knowledge-based chatbot that can answer questions in French across three main categories: education, business, and practical life. The system uses a modern tech stack with React frontend, Express backend, and PostgreSQL database with Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with a clear separation between client-side and server-side code:

- **Frontend**: React 18 with TypeScript, built using Vite
- **Backend**: Node.js with Express server
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Build System**: Vite for development and production builds

## Key Components

### Frontend Architecture
- **Component-based React architecture** with TypeScript for type safety
- **Custom UI components** built on top of Radix UI primitives via shadcn/ui
- **Responsive design** with mobile-first approach using Tailwind CSS
- **African-themed styling** with custom color palette reflecting African culture
- **Real-time chat interface** with message polling for live updates

### Backend Architecture
- **RESTful API** built with Express.js
- **In-memory storage** with fallback interface for database integration
- **Knowledge base system** with categorized responses
- **AI response generation** with context-aware answers
- **Message history** tracking and retrieval

### Database Schema
- **Messages table**: Stores chat messages with sender identification and timestamps
- **Knowledge base table**: Contains categorized questions and responses with array-based question matching
- **PostgreSQL integration** ready with Drizzle ORM configuration

## Data Flow

1. **User Input**: Users type messages in the chat interface
2. **Message Validation**: Frontend validates input using Zod schemas
3. **API Request**: Validated messages sent to Express backend via REST API
4. **Knowledge Processing**: Backend searches knowledge base for relevant responses
5. **AI Response**: System generates contextual responses based on category and content
6. **Database Storage**: Both user messages and AI responses stored in database
7. **Real-time Updates**: Frontend polls for new messages to maintain chat synchronization

## External Dependencies

### Core Framework Dependencies
- **React 18** with modern hooks and concurrent features
- **Express.js** for backend API server
- **Drizzle ORM** for type-safe database operations
- **Neon Database** serverless PostgreSQL for cloud deployment

### UI and Styling
- **Tailwind CSS** for utility-first styling
- **Radix UI** for accessible component primitives
- **Lucide React** for consistent iconography
- **shadcn/ui** for pre-built component patterns

### Development Tools
- **Vite** for fast development and optimized builds
- **TypeScript** for enhanced developer experience and type safety
- **TanStack Query** for efficient server state management
- **Wouter** for lightweight client-side routing

## Deployment Strategy

### Development Environment
- **Vite dev server** for frontend with HMR (Hot Module Replacement)
- **tsx** for running TypeScript server code directly
- **Concurrent development** with frontend and backend running simultaneously

### Production Build
- **Static asset generation** via Vite build process
- **Server bundling** using esbuild for optimized backend code
- **ESM module support** throughout the application
- **Environment-based configuration** for database connections

### Database Management
- **Drizzle migrations** for schema versioning
- **Environment variable configuration** for database URLs
- **Connection pooling** ready for production scaling

The application is designed to be easily deployable to modern hosting platforms with support for both the static frontend and Node.js backend, with PostgreSQL database integration through environment variables.