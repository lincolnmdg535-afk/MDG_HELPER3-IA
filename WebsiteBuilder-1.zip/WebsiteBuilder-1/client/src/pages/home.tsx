import { useState } from "react";
import ChatHeader from "@/components/chat-header";
import KnowledgeCategories from "@/components/knowledge-categories";
import MessagesArea from "@/components/messages-area";
import MessageInput from "@/components/message-input";

export default function Home() {
  const [currentCategory, setCurrentCategory] = useState<string>('all');

  return (
    <div className="min-h-screen flex flex-col bg-african-bg">
      <ChatHeader />
      <KnowledgeCategories 
        currentCategory={currentCategory}
        onCategoryChange={setCurrentCategory}
      />
      
      <main className="flex-1 flex flex-col max-w-4xl mx-auto w-full">
        {/* Welcome Message */}
        <div className="p-4 text-center bg-gradient-to-r from-african-primary to-african-accent text-white">
          <h2 className="text-lg font-semibold mb-2">Bienvenue sur MDG Helper! 🌍</h2>
          <p className="text-sm opacity-90">
            Votre assistant IA spécialisé pour l'Afrique. Posez vos questions sur l'éducation, les affaires, ou la vie pratique.
          </p>
        </div>

        <MessagesArea currentCategory={currentCategory} />
        <MessageInput currentCategory={currentCategory} />
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 p-3 text-center">
        <p className="text-xs text-gray-600">
          MDG Helper - Assistant IA pour l'Afrique 🌍 | 
          <a href="#" className="text-african-primary hover:underline ml-1">À propos</a> | 
          <a href="#" className="text-african-primary hover:underline ml-1">Contact</a>
        </p>
      </footer>
    </div>
  );
}
