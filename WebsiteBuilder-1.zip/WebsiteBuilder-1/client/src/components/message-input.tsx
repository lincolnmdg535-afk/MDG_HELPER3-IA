import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface MessageInputProps {
  currentCategory: string;
}

export default function MessageInput({ currentCategory }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest(
        'POST',
        `/api/messages?category=${currentCategory}`,
        { content, sender: 'user' }
      );
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/messages'] });
      setMessage("");
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer le message. Veuillez réessayer.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedMessage = message.trim();
    
    if (!trimmedMessage) return;
    
    sendMessageMutation.mutate(trimmedMessage);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="border-t border-gray-200 bg-white p-4">
      <form onSubmit={handleSubmit} className="flex space-x-3">
        <div className="flex-1">
          <Input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Pose ta question ici..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-african-primary focus:border-transparent text-african-text"
            disabled={sendMessageMutation.isPending}
          />
        </div>
        <Button
          type="submit"
          disabled={!message.trim() || sendMessageMutation.isPending}
          className="bg-african-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 focus:ring-2 focus:ring-african-primary focus:ring-offset-2 transition-all duration-200 flex items-center space-x-2"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline">
            {sendMessageMutation.isPending ? "Envoi..." : "Envoyer"}
          </span>
        </Button>
      </form>
      <div className="mt-2 text-center">
        <p className="text-xs text-gray-500">Appuyez sur Entrée pour envoyer votre message</p>
      </div>
    </div>
  );
}
