import { Bot } from "lucide-react";

export default function ChatHeader() {
  return (
    <header className="bg-african-primary text-white p-4 shadow-african">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-african-accent rounded-full flex items-center justify-center">
            <Bot className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-xl font-bold">MDG Helper</h1>
            <p className="text-sm opacity-90">Assistant IA pour l'Afrique</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 bg-african-success rounded-full animate-pulse"></span>
          <span className="text-sm hidden sm:inline">En ligne</span>
        </div>
      </div>
    </header>
  );
}
