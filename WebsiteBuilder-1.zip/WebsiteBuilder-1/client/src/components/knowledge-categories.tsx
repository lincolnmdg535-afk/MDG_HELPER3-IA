import { GraduationCap, Briefcase, Wrench, List } from "lucide-react";
import { Button } from "@/components/ui/button";

interface KnowledgeCategoriesProps {
  currentCategory: string;
  onCategoryChange: (category: string) => void;
}

export default function KnowledgeCategories({ currentCategory, onCategoryChange }: KnowledgeCategoriesProps) {
  const categories = [
    { id: 'education', name: 'Éducation', icon: GraduationCap, color: 'bg-african-secondary' },
    { id: 'business', name: 'Business', icon: Briefcase, color: 'bg-african-accent' },
    { id: 'practical', name: 'Pratique', icon: Wrench, color: 'bg-african-success' },
    { id: 'all', name: 'Tout', icon: List, color: 'bg-gray-600' },
  ];

  return (
    <div className="bg-white border-b border-gray-200 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-wrap gap-2 justify-center">
          {categories.map((category) => {
            const Icon = category.icon;
            const isActive = currentCategory === category.id;
            
            return (
              <Button
                key={category.id}
                onClick={() => onCategoryChange(category.id)}
                className={`
                  px-4 py-2 text-white rounded-full text-sm transition-all
                  ${category.color} hover:opacity-90
                  ${isActive ? 'ring-2 ring-white ring-offset-2' : ''}
                `}
              >
                <Icon className="mr-2 w-4 h-4" />
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
