import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bot, User } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { Message } from "@shared/schema";

interface MessagesAreaProps {
  currentCategory: string;
}

export default function MessagesArea({ currentCategory }: MessagesAreaProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isTyping, setIsTyping] = useState(false);

  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ['/api/messages'],
    refetchInterval: 2000, // Poll for new messages
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const formatTimestamp = (timestamp: string | Date) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatMessage = (content: string) => {
    return content.replace(/\n/g, '<br>');
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-4 space-y-4" style={{ height: "calc(100vh - 280px)" }}>
        {[...Array(3)].map((_, i) => (
          <div key={i} className="flex items-start space-x-3">
            <Skeleton className="w-8 h-8 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex-1 p-4 space-y-4 overflow-y-auto" style={{ height: "calc(100vh - 280px)" }}>
      {/* Welcome message */}
      <div className="flex items-start space-x-3">
        <div className="w-8 h-8 bg-african-success rounded-full flex items-center justify-center flex-shrink-0">
          <Bot className="text-white w-4 h-4" />
        </div>
        <div className="max-w-xs lg:max-w-md">
          <div className="bg-african-bot rounded-lg p-3 shadow-sm">
            <p className="text-african-text text-sm">
              Salut! Je suis MDG Helper, ton assistant IA conçu pour l'Afrique. Je peux t'aider avec tes questions sur l'éducation, les opportunités business, et bien plus encore. Comment puis-je t'aider aujourd'hui? 😊
            </p>
          </div>
          <div className="text-xs text-gray-500 mt-1 px-1">Assistant</div>
        </div>
      </div>

      {/* Messages */}
      {messages.map((message) => (
        <div
          key={message.id}
          className={`flex items-start space-x-3 ${
            message.sender === 'user' ? 'justify-end' : ''
          }`}
        >
          {message.sender === 'bot' && (
            <div className="w-8 h-8 bg-african-success rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="text-white w-4 h-4" />
            </div>
          )}
          
          <div className="max-w-xs lg:max-w-md">
            <div
              className={`rounded-lg p-3 shadow-sm ${
                message.sender === 'user'
                  ? 'bg-african-user'
                  : 'bg-african-bot'
              }`}
            >
              <p
                className="text-african-text text-sm"
                dangerouslySetInnerHTML={{ __html: formatMessage(message.content) }}
              />
            </div>
            <div
              className={`text-xs text-gray-500 mt-1 px-1 ${
                message.sender === 'user' ? 'text-right' : ''
              }`}
            >
              {formatTimestamp(message.timestamp)}
            </div>
          </div>
          
          {message.sender === 'user' && (
            <div className="w-8 h-8 bg-african-primary rounded-full flex items-center justify-center flex-shrink-0">
              <User className="text-white w-4 h-4" />
            </div>
          )}
        </div>
      ))}

      {/* Typing indicator */}
      {isTyping && (
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-african-success rounded-full flex items-center justify-center flex-shrink-0">
            <Bot className="text-white w-4 h-4" />
          </div>
          <div className="bg-african-bot rounded-lg p-3 shadow-sm">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-african-text rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-african-text rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-african-text rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  );
}
